/** Automatically generated file. DO NOT MODIFY */
package com.example.bluetoothclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}